import pandas as pd

def downsample_df(df: pd.DataFrame, max_points: int = 10000, y_col: str = None) -> pd.DataFrame:
    """
    Reduced default to 10,000 to prevent Cloud Shell browser freeze.
    """
    if len(df) <= max_points:
        return df
    if y_col:
        keep = int(max_points * 0.2)
        top = df.nlargest(keep, y_col)
        rest = df.drop(top.index)
        sample = rest.sample(max_points - len(top), random_state=42)
        return pd.concat([top, sample])
    return df.sample(max_points, random_state=42)