def choose_resolution(start_pos: int, end_pos: int) -> str:
    """Determines the data resolution based on the genomic region length."""
    if start_pos and end_pos:
        region = end_pos - start_pos
        if region < 5_000_000:
            return "high"
        if region < 50_000_000:
            return "medium"
    return "low"