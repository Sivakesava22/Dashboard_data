from google.cloud import bigquery

PROJECT_ID = "shc-variants"

def get_bq_client():
    """Initializes the BigQuery client."""
    return bigquery.Client(project=PROJECT_ID)