import os
import json
from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse
from pathlib import Path
from app.core.logger import log_step

router = APIRouter()

@router.get("/")
@router.get("/app")
async def app_page(request: Request):
    # 1. Capture ALL params from the URL
    params = dict(request.query_params)
    log_step("DASHBOARD → APP URL RECEIVED", params)
    # 2. Locate and read the app.html file
    template_path = Path("app") / "templates" / "app.html"
    if not template_path.exists():
        return HTMLResponse(content="<h1>Error: app.html not found</h1>", status_code=404)

    html_content = template_path.read_text()

    # 3. HELPER: The "Coalesce" function
    # It picks the first non-empty value and strips Looker quotes
    def get_clean(keys, default=""):
        for k in keys:
            val = params.get(k)
            if val and str(val).strip() != "" and str(val).lower() != "null":
                return str(val).replace('"', '').replace("'", "").strip()
        return default

    # 4. PREPARE REPLACEMENTS
    # This solves the ?Subtype=&subtype=IIS issue by checking multiple keys
    replacements = {
        "__SUBTYPE__":      get_clean(["subtype", "Subtype", "f_subtype"], "AIS"),
        "__INITIAL_PLOT__": get_clean(["plot"], "manhattan"),
        "__SYMBOL__":       get_clean(["Symbol", "symbol", "gene"]),
        "__CHROM__":        get_clean(["Chromosome", "chromosome", "chrom"]),
        "__CONSEQUENCE__":  get_clean(["Consequence", "consequence"]),
        "__CLASS__":        get_clean(["Variant_Class", "variant_class", "class"]),
        "__BIOTYPE__":      get_clean(["Biotype", "biotype"]),
        "__SIFT__":         get_clean(["Sift", "sift"]),
        "__CANONICAL__":    get_clean(["Canonical", "canonical"]),
        "__AF_VAL1__":      get_clean(["Gnom_AD_Af", "af_val1"], "0.05"),
        "__AF_OP__":        get_clean(["af_op"], "lte"),
        "__AF_VAL2__":      get_clean(["af_val2"], "0.10")
    }
    log_step("UI NORMALIZED PARAMETERS", replacements)

    # 5. INJECT INTO HTML
    for key, value in replacements.items():
        # json.dumps turns Python None/Strings into valid JavaScript null/strings
        html_content = html_content.replace(key, json.dumps(value))

    return HTMLResponse(content=html_content)