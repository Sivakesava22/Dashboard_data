from fastapi import APIRouter
from app.services.filter_service import get_filter_options

router = APIRouter()

@router.get("/filter_options")
def options(subtype: str):
    """
    Endpoint to fetch the dropdown options.
    It passes the 'subtype' to the backend so we only fetch 
    genes/chromosomes relevant to that specific subtype.
    """
    return get_filter_options(subtype)