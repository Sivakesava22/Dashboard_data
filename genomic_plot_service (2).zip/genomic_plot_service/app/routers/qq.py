from fastapi import APIRouter, Query
from app.services.qq_service import get_qq_data
from typing import Optional
from app.core.logger import log_step
router = APIRouter()

@router.get("/qq_data")
def qq_endpoint(
    subtype: str, 
    chromosome: str = None, 
    gene: str = None,
    consequence: str = None, 
    canonical: str = None,
    biotype: str = None,
    variant_class: str = None, 
    sift: str = None,          
    af_op: str = "lte",        
    af_val1: float = 0.05,     
    # Change: Use Optional[str] to prevent float parsing errors on empty strings
    af_val2: Optional[str] = None 
):
    """
    Endpoint for Q-Q plot data. 
    Accepts af_val2 as a string to handle conditional UI inputs safely.
    """
    log_step("QQ ROUTER INPUT", locals())
    # locals() passes the parameters to the service for SQL construction
    return get_qq_data(locals())