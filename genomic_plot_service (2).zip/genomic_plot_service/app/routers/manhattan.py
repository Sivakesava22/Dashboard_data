from fastapi import APIRouter, Query
from app.services.manhattan_service import get_manhattan_data
from typing import Optional
from app.core.logger import log_step
router = APIRouter()

@router.get("/manhattan_data")
def manhattan_endpoint(
    subtype: str, 
    chromosome: str = None, 
    gene: str = None,
    consequence: str = None, 
    canonical: str = None,
    biotype: str = None,
    variant_class: str = None, # Added to match app.html
    sift: str = None,          # Added to match app.html
    af_op: str = "lte",        # Added to match app.html
    af_val1: float = 0.05,     # Changed from af_threshold
    af_val2: Optional[str] = None      # Accepts None or "" safely
):
    log_step("MANHATTAN ROUTER INPUT", locals())
    return get_manhattan_data(locals())