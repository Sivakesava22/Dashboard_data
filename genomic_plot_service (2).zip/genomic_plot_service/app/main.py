from fastapi import FastAPI
from fastapi.middleware.gzip import GZipMiddleware
from app.routers import manhattan, qq, filters, ui
from app.core.logger import logger, log_step
log_step("APPLICATION STARTUP")
app = FastAPI(title="Genomic Plot Service")

# Apply GZip compression to handle coordinate-heavy JSON responses
app.add_middleware(GZipMiddleware, minimum_size=1000)

app.include_router(manhattan.router)
app.include_router(filters.router)
app.include_router(ui.router)
app.include_router(qq.router)