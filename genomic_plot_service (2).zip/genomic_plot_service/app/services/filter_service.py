from app.services.bigquery_client import client
from google.cloud import bigquery
from app.core.logger import log_step
def get_filter_options(subtype_param):
    """
    Fetches pre-calculated filter lists from the summary table.
    """
    filters = {
        "chromosome": [], "gene": [], "consequence": [], 
        "variant_class": [], "biotype": [], "sift": [], 
        "canonical": [], "subtype": []
    }
    
    sql_data = """
        SELECT 
            chromosome, gene, canonical, consequence, 
            variant_class, biotype, sift
        FROM `shc-variants.igg_dev.variant_filter_options`
        WHERE subtype = @subtype
    """
    
    sql_subtypes = """
        SELECT DISTINCT subtype 
        FROM `shc-variants.igg_dev.variant_filter_options`
        ORDER BY subtype
    """

    try:
        job = client.query(sql_data, job_config=bigquery.QueryJobConfig(
            query_parameters=[bigquery.ScalarQueryParameter("subtype", "STRING", subtype_param)]
        ))
        
        results = list(job.result())
        if results:
            row = results[0]
            filters["chromosome"] = sorted(row.chromosome) if row.chromosome else []
            filters["gene"] = sorted(row.gene) if row.gene else []
            filters["canonical"] = sorted(row.canonical) if row.canonical else []
            filters["consequence"] = sorted(row.consequence) if row.consequence else []
            filters["variant_class"] = sorted(row.variant_class) if row.variant_class else []
            filters["biotype"] = sorted(row.biotype) if row.biotype else []
            filters["sift"] = sorted(row.sift) if row.sift else []
            
        job_sub = client.query(sql_subtypes)
        filters["subtype"] = [r.subtype for r in job_sub.result()]

    except Exception as e:
        print(f"Error fetching cached options: {e}")
        return filters
        
    return filters

def build_sql_filters(params: dict):
    """
    Constructs a clean WHERE clause for BigQuery.
    - Sanitizes Looker quotes (%22).
    - Normalizes duplicate keys (e.g., 'Subtype' vs 'subtype').
    - Handles 'chr' prefix for chromosomes.
    """
    where = []
    query_params = []

    # 1. PARAMETER NORMALIZATION
    # Maps all possible incoming keys (Looker/App/Legacy) to one internal key
    mapping = {
        "subtype": ["subtype", "Subtype", "f_subtype"],
        "gene": ["gene", "Symbol", "symbol"],
        "chrom": ["chromosome", "Chromosome", "chrom"],
        "conseq": ["consequence", "Consequence"],
        "class": ["variant_class", "Variant_Class", "class"],
        "biotype": ["biotype", "Biotype"],
        "sift": ["sift", "Sift"],
        "canonical": ["canonical", "Canonical"]
    }
    log_step("FILTER BUILDER INPUT", params)
    normalized = {}
    for internal_key, url_keys in mapping.items():
        for uk in url_keys:
            val = params.get(uk)
            # Only process if value is not empty or "All"
            if val and str(val).strip() != "" and str(val).lower() != "all":
                # SANITIZATION: Strip quotes (%22) that Looker often adds
                clean_val = str(val).replace('"', '').replace("'", "").strip()
                normalized[internal_key] = clean_val
                break # Stop after finding the first valid value for this category
    log_step("FILTER BUILDER NORMALIZED", normalized)

    # 2. MAP TO BIGQUERY COLUMNS
    column_defs = [
        ("m.subtype", "subtype"),
        ("d.gene_symbol", "gene"),
        ("d.chromosome_name", "chrom"),
        ("d.Consequence", "conseq"),
        ("d.Variant_Class", "class"),
        ("d.Biotype", "biotype"),
        ("d.Sift", "sift"),
        ("d.Canonical", "canonical")
    ]

    for col, key in column_defs:
        val = normalized.get(key)
        if val:
            # Normalization: Ensure chromosome always starts with 'chr'
            if key == "chrom" and not val.startswith("chr"):
                val = f"chr{val}"
            
            param_id = f"p_{key}"
            where.append(f"{col} = @{param_id}")
            query_params.append(bigquery.ScalarQueryParameter(param_id, "STRING", val))

    # 3. ALLELE FREQUENCY (AF) LOGIC
    op = params.get("af_op", "lte")
    # Priority: Looker Gnom_AD_Af -> App af_val1
    val1_str = params.get("Gnom_AD_Af") or params.get("af_val1")
    
    try:
        # Clean quotes from numerical strings too
        val1 = float(str(val1_str).replace('"', '')) if val1_str else 0.05
    except (ValueError, TypeError):
        val1 = 0.05

    if op == "between":
        try:
            val2 = float(str(params.get("af_val2", "0.10")).replace('"', ''))
        except:
            val2 = 0.10
        where.append("d.allele_frequency BETWEEN @af_v1 AND @af_v2")
        query_params.append(bigquery.ScalarQueryParameter("af_v1", "FLOAT64", min(val1, val2)))
        query_params.append(bigquery.ScalarQueryParameter("af_v2", "FLOAT64", max(val1, val2)))
    else:
        op_map = {"lte": "<=", "gte": ">=", "eq": "=", "lt": "<", "gt": ">"}
        sql_op = op_map.get(op, "<=")
        where.append(f"d.allele_frequency {sql_op} @af_v1")
        query_params.append(bigquery.ScalarQueryParameter("af_v1", "FLOAT64", val1))

    # Return "1=1" if no filters are applied to avoid invalid SQL
    final_where = " AND ".join(where) if where else "1=1"
    log_step("FILTER BUILDER OUTPUT", {
    "where_sql": final_where,
    "query_params": [str(p) for p in query_params]
    })
    return final_where, query_params