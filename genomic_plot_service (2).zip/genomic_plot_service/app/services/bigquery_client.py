from app.core.config import get_bq_client

client = get_bq_client()