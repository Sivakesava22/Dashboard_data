import pandas as pd
import time
from app.services.bigquery_client import client
from app.services.filter_service import build_sql_filters
from app.utils.sampling import downsample_df
from app.core.logger import log_step
from google.cloud import bigquery

# Standard Plotly colors
CHROM_COLORS = [
    "#1F77B4", "#FF7F0E", "#2CA02C", "#D62728", "#9467BD", 
    "#8C564B", "#E377C2", "#7F7F7F", "#BCBD22", "#17BECF", 
    "#00008B", "#FF00FF", "#4B0082", "#FFD700", "#006400", 
    "#DC143C", "#00CED1", "#8B4513", "#FF4500", "#2E8B57", 
    "#4682B4", "#CD5C5C"
]

def get_manhattan_data(params: dict):
    # 1. Generate SQL filters from incoming params
    # Ensure build_sql_filters handles both 'Symbol' (Looker) and 'gene' (App)
    where_sql, query_params = build_sql_filters(params)

    # 2. VOLUME CHECK: Short-circuit count (Limit 10,001)
    # This prevents counting to 122M if we just need to know if it's "large"
    check_query = f"""
        SELECT COUNT(*) as total FROM (
            SELECT 1 FROM `shc-variants.igg_dev.variant_dimension` d
            JOIN `shc-variants.igg_dev.variant_subtype_metrics` m ON d.id = m.id
            WHERE {where_sql}
            LIMIT 10001
        )
    """
    
    try:
        count_job = client.query(check_query, job_config=bigquery.QueryJobConfig(query_parameters=query_params))
        total_found = next(count_job.result()).total
        # If it's 10,000 or less, we show every single variant (Raw)
        use_raw_data = total_found <= 10000
        log_step("MANHATTAN_RESOLUTION_DECISION", {"use_raw": use_raw_data, "count_detected": total_found})
    except Exception as e:
        log_step("VOLUME_CHECK_ERROR", {"msg": str(e)})
        use_raw_data = False # Fallback to safety binning

    # 3. CONSTRUCT MAIN QUERY
    if use_raw_data:
        # MICROSCOPE MODE: Exact coordinates for every variant
        pos_logic = "d.position"
        select_metric = "ABS(m.percent_diff)"
        gene_logic = "d.gene_symbol" # Removed ANY_VALUE
        group_logic = ""
        resolution_label = "Individual Variants"
        join_type = "JOIN"
    else:
        # SATELLITE MODE: Binning millions of points into 150kb chunks
        pos_logic = "CAST(d.position / 150000 AS INT64) * 150000"
        select_metric = "MAX(ABS(m.percent_diff))"
        gene_logic = "ANY_VALUE(d.gene_symbol)" # Keep ANY_VALUE for grouping
        group_logic = "GROUP BY chrom_num, pos_display"
        resolution_label = "Regional Averages (Binned)"
        join_type = "JOIN"

    # We remove the subtype from the WHERE because it's now in the JOIN
    adjusted_where = where_sql.replace("m.subtype = @p_subtype", "1=1")

    query = f"""
    SELECT
        SAFE_CAST(REPLACE(d.chromosome_name, 'chr', '') AS INT64) AS chrom_num,
        {pos_logic} AS pos_display,
        {select_metric} AS percent_diff,
        {gene_logic} AS gene_symbol
    FROM `shc-variants.igg_dev.variant_dimension` d
    {join_type} `shc-variants.igg_dev.variant_subtype_metrics` m ON d.id = m.id 
    AND m.subtype = @p_subtype
    WHERE {adjusted_where}
    AND SAFE_CAST(REPLACE(d.chromosome_name, 'chr', '') AS INT64) BETWEEN 1 AND 22
    {group_logic}
    ORDER BY chrom_num, pos_display
    """

    try:
        job = client.query(query, job_config=bigquery.QueryJobConfig(query_parameters=query_params))
        df = job.result().to_dataframe()
    except Exception as e:
        log_step("MANHATTAN_QUERY_ERROR", {"msg": str(e), "query": query})
        return {"error": str(e)}

    if df.empty:
        return {"running_pos": [], "percent_diff": [], "gene_symbol": [], "color": [], "tick_vals": [], "tick_text": []}

    # 4. POST-PROCESSING: Sequential Genomic Layout
    df = df.fillna({"gene_symbol": ""})
    df['color'] = df['chrom_num'].apply(lambda x: CHROM_COLORS[(int(x)-1) % len(CHROM_COLORS)])

    df['running_pos'] = 0
    cumulative_offset = 0
    tick_vals = []
    tick_text = []

    # Iterate through chromosomes to create the continuous X-axis
    for chrom, grp in df.groupby('chrom_num'):
        max_pos_in_chrom = grp['pos_display'].max()
        df.loc[grp.index, 'running_pos'] = grp['pos_display'] + cumulative_offset
        
        # Place label at the center of the chromosome region
        tick_vals.append(cumulative_offset + (max_pos_in_chrom / 2))
        tick_text.append(str(int(chrom)))
        
        # Buffer (2MB) between chromosomes to prevent overlap
        cumulative_offset += max_pos_in_chrom + 2000000

    return {
        "running_pos": df['running_pos'].tolist(),
        "percent_diff": df['percent_diff'].tolist(),
        "gene_symbol": df['gene_symbol'].tolist(),
        "color": df['color'].tolist(),
        "tick_vals": tick_vals,
        "tick_text": tick_text,
        "resolution": resolution_label # Passed to frontend to show data status
    }