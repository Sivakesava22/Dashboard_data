import time
import pandas as pd
from google.cloud import bigquery
from app.services.bigquery_client import client
from app.services.filter_service import build_sql_filters 
from app.utils.sampling import downsample_df
from app.core.logger import log_step

def get_qq_data(params: dict):
    start_time = time.time()
    
    # 1. GENERATE DYNAMIC FILTERS
    where_sql, query_params = build_sql_filters(params)

    # 2. VOLUME CHECK (Short-circuit count)
    # We check if there are more than 10,000 matches to decide on aggregation.
    check_query = f"""
        SELECT COUNT(*) as total FROM (
            SELECT 1 FROM `shc-variants.igg_dev.variant_subtype_metrics` m
            JOIN `shc-variants.igg_dev.variant_dimension` d ON d.id = m.id
            WHERE {where_sql}
            LIMIT 10001
        )
    """
    
    try:
        count_job = client.query(check_query, job_config=bigquery.QueryJobConfig(query_parameters=query_params))
        total_found = next(count_job.result()).total
        use_raw_data = total_found <= 10000
    except Exception as e:
        log_step("QQ_VOLUME_CHECK_ERROR", {"msg": str(e)})
        use_raw_data = False # Default to safety aggregation

    # 3. CONSTRUCT ADAPTIVE QUERY
    if use_raw_data:
        # HIGH RESOLUTION
        # Using JOIN and IFNULL to ensure 28/28 variants show up
        x_logic = "IFNULL(m.control_percent, 0)"
        y_logic = "IFNULL(m.control_percent + m.percent_diff, 0)"
        group_logic = ""
        join_type = "JOIN"
        resolution_label = "Individual Variants"
    else:
        # AGGREGATED MODE: Spatial rounding to handle millions of points
        # Rounding to 5 decimal places collapses 122M rows into ~10-20k unique visual clusters.
        x_logic = "ROUND(IFNULL(m.control_percent, 0), 5)"
        y_logic = "ROUND(IFNULL(m.control_percent + m.percent_diff, 0), 5)"
        group_logic = "GROUP BY x_val, y_val"
        join_type = "JOIN"
    # We remove the subtype from the WHERE because it's now in the JOIN
    adjusted_where = where_sql.replace("m.subtype = @p_subtype", "1=1")

    sql = f"""
        SELECT 
        {x_logic} as x_val, 
        {y_logic} as y_val
    FROM `shc-variants.igg_dev.variant_dimension` d
        {join_type} `shc-variants.igg_dev.variant_subtype_metrics` m ON d.id = m.id
        AND m.subtype = @p_subtype
    WHERE {adjusted_where}
        {group_logic}
        """
    resolution_label = "Frequency Clusters (Aggregated)"

    log_step("QQ_RESOLUTION_DECISION", {"mode": resolution_label, "use_raw": use_raw_data})

    # 4. EXECUTION
    bq_start = time.time()
    try:
        job = client.query(sql, job_config=bigquery.QueryJobConfig(query_parameters=query_params))
        df = job.result().to_dataframe()
    except Exception as e:
        log_step("QQ_QUERY_ERROR", {"msg": str(e)})
        return {"x": [], "y": [], "resolution": "Error"}
        
    bq_duration = time.time() - bq_start

    if df.empty:
        return {"x": [], "y": [], "resolution": "No Data Found"}

    # 5. FINAL SAMPLING (Safety check for browser performance)
    if len(df) > 10000:
        df = downsample_df(df, 8000)

    total_duration = time.time() - start_time
    
    # Console Logging for Debugging
    print(f"\n[Q-Q Plot - {resolution_label}] -----------------------------")
    print(f"   BigQuery Time:   {bq_duration:.4f} sec")
    print(f"   Points Loaded:   {len(df)}")
    print(f"   Total App Time:  {total_duration:.4f} sec")
    print(f"----------------------------------------------------------\n")

    return {
        "x": df['x_val'].tolist(), 
        "y": df['y_val'].tolist(),
        "resolution": resolution_label
    }